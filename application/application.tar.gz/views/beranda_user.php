<div class="well" style="text-align:center;">
	<h3><strong>Sistem Pendukung Keputusan Pemindahan Tugas Pegawai</strong></h3>
	<h3><strong>PT Asuransi Umum Bumiputera Muda 1967</strong></h3>
</div>	
<div class="well">
	<h4>Selamat Datang</h4>
	Lengkapi dan perbarui data anda untuk kualitas penilaian yang lebih baik.
</div>									